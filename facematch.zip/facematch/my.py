data = "UI"
print(data)